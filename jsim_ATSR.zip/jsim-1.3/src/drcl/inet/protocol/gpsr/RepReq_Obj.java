// RepReq_Obj.java
// Copyright (c) 2008-2010, Technological Educational Institute (TEI) of Chalkida
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
// *	Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer.
// *	Redistributions in binary form must reproduce the above copyright notice,
//	this list of conditions and the following disclaimer in the documentation 
//	and/or other materials provided with the distribution.
// *	Neither the name of the TEI of Chalkida nor the names of its contributors 
//	may be used to endorse or promote products derived from this software without 
//	specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

/* RepRes_Obj.java ATSR support  25102008
 * in this obj we keep the necessary info about each REPREQ msg 
 * in order to know how many msg the node has send, the nodes
 * asked reputation and the current nbr table at the instance of each 
 * transmission*/

package drcl.inet.protocol.gpsr;

import java.util.Vector;
import java.util.*;
import drcl.data.*;
import drcl.comp.*;

//
//Code for ATSR support, http://www.ee.teihal.gr/professors/voliotis/digilab_site/ATSR_home.html
//authors: Panagiotis Karkazis, Sotirios Maniatis, Panagiotis Trakadas
//

public class RepReq_Obj /*extends drcl.inet.protocol.Routing implements ActiveComponent*/ {
    
	/***ATSR support -start***/
	/** Debug level defined for ATSR support */
	public static final int DEBUG_ORIGINAL	= 0;
	public static final int DEBUG_SOT_SEND	= 1;
	public static final int DEBUG_SOT_RCV	= 2;
	
	static final String[] DEBUG_LEVELS = {"original", "sotsend", "sotrcv"};
	
    /** Returns the names of defined debug levels; subclasses should override this method if debug levels are defined. */
	public String[] getDebugLevelNames()
	{ return DEBUG_LEVELS; }
	
	//ATSR support  start 28112008
	long ChosenNd;			  	//stores the id of the node which I asked for REPREQ
	Vector ChosenNdNbrList;		//stores the respond nbr list from chosen Node
	Vector ChosenNdDirTrVal;	//stores the respond direct trust value list from chosen Node
	boolean ReplyArrived;
	
	public RepReq_Obj(long ChosenNode_)
	{
		this.ChosenNd=ChosenNode_;
		
		ChosenNdNbrList = new Vector();
		ChosenNdDirTrVal = new Vector();
		ReplyArrived=false;
	}
	
	public long getChosenNd()
	{
		return ChosenNd;
	}
	
	public void setChosenNdDirTrVal(Vector vector)
	{
		this.ChosenNdDirTrVal=vector;
	}
	
	public Vector getChosenNdDirTrVal()
	{
		return this.ChosenNdDirTrVal;
	}
	
	public void setChosenNdNbrList(Vector vector)
	{
		this.ChosenNdNbrList=vector;
	}
	
	public Vector getChosenNdNbrList()
	{
		return this.ChosenNdNbrList;
	}
	
	public long getChosenNdNbr(int index)
	{
		return (long)((Long)ChosenNdNbrList.get(index)).longValue();
	}
	
	//search for a trust value either by 1. index or 2. node id
	//1.
	public double getChosenNdDirTrVal(int index)
	{
		return (double)((Double)ChosenNdDirTrVal.get(index)).doubleValue();
	}	
	//2.
	public double getChosenNdDirTrVal (long MyNbr_node_id)
	{
		int index=ChosenNdNbrList.indexOf(new Long(MyNbr_node_id));
		if (index==-1) //not found
			return -1.0;
		return (double)((Double)ChosenNdDirTrVal.get(index)).doubleValue();
	}

	public boolean isRepResArrived(/*long MyNbr_node_id*/)
	{	
		return this.ReplyArrived;//ChosenNdNbrList.contains(new Long(MyNbr_node_id));
	}
	//ATSR support  end 28112008
}

