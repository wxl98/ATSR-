ATSR for J-Sim Version 1.0

The ATSR software is provided as an extension to the GPSR routing
protocol implementation for J-Sim. The software also implements 
enhancements to the J-Sim code to support overhearing at the MAC 
layer and modifies the energy model.

ATSR homepage: 
http://www.ee.teihal.gr/professors/voliotis/digilab_site/ATSR_home.html

Installation instructions:
http://www.ee.teihal.gr/professors/voliotis/digilab_site/ATSR_for_JSIM.html

After this software is installed it may be used to run either the original
GPSR or its enhanced version with the features of the ATSR. The discrimination
between GPSR and ATSR is done through appropriate commands in the Tcl file.

An example is provided as atsr_100nodes_Random.tcl in the directory
jsim-1.3\script\drcl\inet\gpsr.

