// @(#)FSPMessage.java   6/2005
// Copyright (c) 1998-2005, Distributed Real-time Computing Lab (DRCL) 
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer. 
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution. 
// 3. Neither the name of "DRCL" nor the names of its contributors may be used
//    to endorse or promote products derived from this software without specific
//    prior written permission. 
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 

package drcl.inet.application;

import drcl.comp.*;
import drcl.net.*;
import drcl.data.*;
import drcl.util.ObjectUtil;

//
// This file is a modified version of the original file included in the J-Sim distribution. 
// The modifications implement the ATSR routing protocol.
// The code changes and additions to support the ATSR are surrounded by comments.
// The software is refered to:
// -	ATSR homepage: http://www.ee.teihal.gr/professors/voliotis/digilab_site/ATSR_home.html
// -	T. Zahariadis, H. Leligou, S. Voliotis, S. Maniatis, P. Trakadas, P. Karkazis, 
//	"An Energy and Trust-aware Routing Protocol for Large  Wireless Sensor Networks", 
//	WSEAS Transactions on Communications, Sept. 2009.
// -	T. Zahariadis, H. Leligou, P. Karkazis, P. Trakadas, I. Papaefstathiou, C. Vangelatos, L. Besson,
//	"Design and implementation of a trust-aware routing protocol for large WSNs", 
//	Int. Journal of Network Security & Its Applications, July 2010.
// - 	H. C. Leligou, P. Trakadas, S. Maniatis, P. Karkazis and T. Zahariadis,
//	"Combining trust with location information for routing in wireless sensor networks",
//	Wireless Communications and Mobile Computing, Dec 2010.
//
// authors: Panagiotis Karkazis, Sotirios Maniatis, Panagiotis Trakadas
//


/** The file service protocol message. */
public class awFSPMessage implements drcl.ObjectCloneable
{
	String fileName;
	int code;
	double pktSN;
	long startIndex, endIndex;
	long size ;
	Object content;// could be null (request), byte[], (reply) or String (error)
	int msgSize;
	int replyTimeout;
	double simulationTime;
	long sessionID = 0;				//ATSR support 25042011
	int rpl_instance = Integer.MAX_VALUE; //ATSR support 25042011
	// errors
	public static final int EXCEPTION = 0;
	public static final int FILE_NOT_EXIST = 1;
	
	public awFSPMessage()
	{ super(); }
	
	/**
	 * Constructor for the FSP request.
	 * 
	 * @param code_ the code sent by server in the previous reply.
	 * @param endIndex_ the end byte index, exclusive.
	 */
	public awFSPMessage(String fileName_, int code_, long startIndex_,
										long endIndex_, int replyTimeout_)
	{
		fileName = fileName_;
		code = code_;
		startIndex = startIndex_;
		endIndex = endIndex_;
		replyTimeout = replyTimeout_;
		
	}
	
	/**
	 * Constructor for the FSP reply.
	 * 
	 * @param code_ the code for next request.
	 * @param endIndex_ the end byte index, exclusive.
	 */
	public awFSPMessage(String fileName_, int code_, long startIndex_,
					   long endIndex_, long size_, byte[] content_, double simulationTime_)
	{
		fileName = fileName_;
		code = code_;
		startIndex = startIndex_;
		endIndex = endIndex_;
		size = size_;
		content = content_;
		simulationTime = simulationTime_;
	}
	
	public awFSPMessage(String fileName_, int code_, long startIndex_,
					   long endIndex_, long size_, byte[] content_, double simulationTime_, double pktSN_)
	{
		fileName = fileName_;
		code = code_;
		startIndex = startIndex_;
		endIndex = endIndex_;
		size = size_;
		content = content_;
		simulationTime = simulationTime_;
		pktSN = pktSN_;
	}
	/** Constructor for the FSP error reply. */
	public awFSPMessage(String fileName_, int errorCode_, String error_)
	{
		fileName = fileName_;
		code = errorCode_;
		content = error_;
	}
	
	public double getSimulationTime()
	{ return simulationTime; }

	public int getReplyTimeout()
	{ return replyTimeout; }
	
	public String getFileName()
	{ return fileName; }
	
	public long getStartIndex()
	{ return startIndex; }
	
	public long getEndIndex()
	{ return endIndex; }
	
	public int getCode()
	{ return code; }
	
	public int getErrorCode()
	{ return code; }
	
	public byte[] getFileContent()
	{ return (byte[])content; }

	public long getFileSize()
	{ return size; }
	
	public String getError()
	{ return (String)content; }

	public boolean isError()
	{ return content instanceof String; }

	public boolean isRequest()
	{ return content == null; }

	public boolean isReply()
	{ return content != null; }
	//ATSR support start 25042011
	public long getSession()
	{ return sessionID; }
	
	public long setSession(long session_id)
	{ return sessionID = session_id; }

	public int getRplInstID()
	{ return rpl_instance; }
	
	public int setRplInstID(int instid)
	{ return rpl_instance = instid; }
	//ATSR support end 25042011
	
	public String toString()
	{
		if (content == null) {
			// a request
			return "FSP_REQUEST:" + fileName
					+ "(" + startIndex + "-" + endIndex + "),code=" + code;
		}
		else if (content instanceof String) {
			// an error
			return "FSP_ERROR:" + fileName + "," + code + ",'" + content + "'";
		}
		else {
			// a reply
			return "FSP_REPLY:" + fileName + "(" + size + ","
				+ startIndex + "-" + endIndex
				+ "),content=" + drcl.util.StringUtil.toString(content)
				+ ",code=" + code;
		}
	}

	public Object clone()
	{
		awFSPMessage m = new awFSPMessage();
		m.fileName = fileName;
		m.code = code;
		m.startIndex = startIndex;
		m.endIndex = endIndex;
		m.size = size;
		m.msgSize = msgSize;
		m.replyTimeout = replyTimeout;
		m.simulationTime = simulationTime;
		m.content = drcl.util.ObjectUtil.clone(content);
		m.pktSN = pktSN;
		m.sessionID = sessionID;		//ATSR support 25045011
		m.rpl_instance =rpl_instance;	//ATSR support 25045011
		return m;
	}
}




